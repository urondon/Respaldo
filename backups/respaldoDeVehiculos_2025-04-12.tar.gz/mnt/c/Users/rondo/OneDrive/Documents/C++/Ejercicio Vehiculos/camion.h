#ifndef CAMION_H_
#define CAMION_H_
#include "vehiculo.h"

class Camion : public Vehiculo //herencia//
{
    private:
        int carga;

    public:
        void setCarga(int c);
        int getCarga();
        void imprimir();
};
#endif /*CAMION_H_*/
