#ifndef VEHICULO_H_
#define VEHICULO_H_

class Vehiculo
{
private:
    int ruedas;
    int pasajeros;
public:
    void setRuedas(int r);
    void setPasajeros(int p);
    int getRuedas();
    int getPasajeros();
};
#endif /*VEHICULO_H_*/
