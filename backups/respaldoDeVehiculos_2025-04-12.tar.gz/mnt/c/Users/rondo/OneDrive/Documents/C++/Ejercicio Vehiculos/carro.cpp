#include "carro.h"
#include <iostream>
using namespace std;

void Carro::setTipoauto(enum tipo t)
{
    tipocarro = t;
}

enum tipo Carro::getTipoauto()
{
    return tipocarro;
}

void Carro::imprimir()
{
    cout << "Ruedas: " << getRuedas() << endl;
    cout << "Pasajeros: " << getPasajeros() << endl;
    cout << "Tipo: ";

    switch (getTipoauto())
    {
    case coupe:
        cout << "Coupe" << endl;
        break;
    
    case sedan: 
        cout << "Sedan" << endl;
        break;
    
    case camioneta:
        cout << "Camioneta" << endl;
    }
    cout << endl;
}