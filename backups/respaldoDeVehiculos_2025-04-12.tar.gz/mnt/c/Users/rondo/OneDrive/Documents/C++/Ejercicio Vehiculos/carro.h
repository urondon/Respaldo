#ifndef CARRO_H_
#define CARRO_H_
#include "vehiculo.h"

enum tipo {coupe, sedan, camioneta};

class Carro : public Vehiculo
{
    private:
        enum tipo tipocarro;
    public:
        void setTipoauto(enum tipo t);
        enum tipo getTipoauto();
        void imprimir();
};
#endif /*CARRO_H_*/