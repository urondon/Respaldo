#include "camion.h"
#include "carro.h"
#include <iostream>
using namespace std;

int main(){
    Camion c1,c2;
    Carro a1;

    c1.setCarga(3200);
    c1.setPasajeros(2);
    c1.setRuedas(18);

    c2.setCarga(1200);
    c2.setPasajeros(3);
    c2.setRuedas(6);

    c1.imprimir();
    c2.imprimir();

    a1.setPasajeros(6);
    a1.setRuedas(4);
    a1.setTipoauto(camioneta);

    a1.imprimir();

    Camion *vector;
    vector = new Camion[2];

    *vector = c1;
    *(vector + 1) = c2;

    vector[0].imprimir();
    vector[1].imprimir();

    return 0;

}