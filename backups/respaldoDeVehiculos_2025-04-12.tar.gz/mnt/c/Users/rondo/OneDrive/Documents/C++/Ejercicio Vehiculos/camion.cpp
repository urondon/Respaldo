#include "camion.h"
#include <iostream>
using namespace std;

void Camion::setCarga(int c)
{
    carga = c;
}
int Camion::getCarga()
{
    return carga;
}
void Camion::imprimir()
{
    cout << "Ruedas: " << getRuedas() << endl;
    cout << "Pasajeros: " << getPasajeros() << endl;
    cout << "La capacidad de carga en Kg: " << carga << endl << endl;
}