#include "vehiculo.h"

void Vehiculo::setRuedas(int r)
{
    ruedas = r;
}
void Vehiculo::setPasajeros(int p)
{
    pasajeros = p;
}
int Vehiculo::getRuedas()
{
    return ruedas;
}
int Vehiculo::getPasajeros()
{
    return pasajeros;
}